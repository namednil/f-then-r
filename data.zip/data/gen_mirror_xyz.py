import random

def write_data(d, fname):
    with open(fname, "w") as f:
        for x,y in d:
            f.write(" ".join(x))
            f.write("\t")
            f.write(" ".join(y))
            f.write("\n")
            
def insert(s, pos, block):
    return s[:pos] + block + s[pos:]
            
def gen_data(n, lengths, symbols, add_artifact):
    data = []
    for i in range(n):
        l = random.choice(lengths)
        
        if add_artifact:
            i = "".join([random.choice(symbols) for _ in range(l)])
            if l + 3 in lengths:
                # it's safe to add one cluster
                if random.random() < 0.2:
                    pos = random.randint(0, l)
                    i = insert(i, pos, "xyz")
        else:
            i = "".join([random.choice(symbols) for _ in range(l)])
            
        o = [x for x in i] + [x for x in reversed(i)]
                
        data.append((tuple(i),tuple(o)))

    return data
    
    
random.seed(42)
symbols = "abcdefghijk"
symbol2i = {x : random.randint(0, 4) for i, x in enumerate(symbols)}

my_range = list(range(3, 10))

train_data = gen_data(4000, my_range, symbols, add_artifact=True) # 3 - 9
dev_data = gen_data(200, my_range, symbols, add_artifact=True) # 10

write_data(train_data, "mirror_xyz/train.tsv")
write_data(dev_data, "mirror_xyz/dev.tsv")

        
test_data = []
while len(test_data) < 1000:
    datum = gen_data(1, my_range, symbols+"xyz", add_artifact=False)[0]
    l, r = datum
    l = "".join(l)
    if "xyz" not in l and ("x" in l or "y" in l or "z" in l):
        test_data.append(datum)
    

write_data(test_data, "mirror_xyz/test.tsv")


    
        
