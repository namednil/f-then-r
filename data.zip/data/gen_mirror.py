import random

def write_data(d, fname):
    with open(fname, "w") as f:
        for x,y in d:
            f.write(" ".join(x))
            f.write("\t")
            f.write(" ".join(y))
            f.write("\n")
            
def gen_data(n, lengths):
    data = []
    for i in range(n):
        l = random.choice(lengths)
        i = [random.choice(symbols) for _ in range(l)]
        o = [x for x in i] + [x for x in reversed(i)]
                
        data.append((tuple(i),tuple(o)))

    return data
    
random.seed(42)
symbols = "abcdefghijk"
symbol2i = {x : random.randint(0, 4) for i, x in enumerate(symbols)}

train_data = gen_data(4000, list(range(3, 10))) # 3 - 9
dev_data = gen_data(200, list(range(10, 11))) # 10

write_data(train_data, "mirror/train.tsv")
write_data(dev_data, "mirror/dev.tsv")
write_data(gen_data(500, list(range(3, 10))), "mirror/dev_iid.tsv")


write_data(gen_data(1000, list(range(11, 21))), "mirror/test.tsv") # 11 - 20


    
        
